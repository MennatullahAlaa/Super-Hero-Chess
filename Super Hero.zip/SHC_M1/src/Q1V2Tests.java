import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import model.game.Direction;
import model.pieces.Piece;
import org.junit.Test;

public class Q1V2Tests {

	final String cellPath = "model.game.Cell";
	final String slideCellPath = "model.game.SlideCell";
	final String blockCellPath = "model.game.BlockCell";
	final String piecePath = "model.pieces.Piece";
	final String unAllowedMoveInBlockPath = "exceptions.UnAllowedMovementInBlockCell";
	final String invalidMovementExceptionPath = "exceptions.InvalidMovementException";
	final String playerPath = "model.game.Player";
	final String gamePath = "model.game.Game";
	final String medicPath = "model.pieces.heroes.Medic";
	final String directionPath = "model.game.Direction";

	@Test(timeout = 100)
	public void testInstanceVariableCell() throws Exception {
		testInstanceVariableIsPresent(Class.forName(cellPath), "piece", true);
		testInstanceVariableIsPresent(Class.forName(cellPath), "blocks", false);
		testInstanceVariableIsPresent(Class.forName(cellPath), "direction",
				false);
	}

	@Test(timeout = 100)
	public void testClassIsSubclassSlideCell() throws Exception {
		testClassIsSubclass(Class.forName(slideCellPath),
				Class.forName(cellPath));
	}

	@Test(timeout = 100)
	public void testInstanceVariableSlideCellPiece() throws Exception {
		testInstanceVariableIsPresent(Class.forName(slideCellPath), "piece",
				false);
	}

	@Test(timeout = 100)
	public void testInstanceVariableSlideCellDirection() throws Exception {
		testInstanceVariableIsPresent(Class.forName(slideCellPath),
				"direction", true);
		testInstanceVariableIsPrivate(Class.forName(slideCellPath), "direction");
	}

	@Test(timeout = 100)
	public void testConstructorSlideCell1() throws Exception {
		@SuppressWarnings("rawtypes")
		Class[] inputs = { Class.forName(directionPath) };
		testConstructorExists(Class.forName(slideCellPath), inputs);
	}

	@Test(timeout = 100)
	public void testConstructorSlideCell2() throws Exception {
		@SuppressWarnings("rawtypes")
		Class[] inputs = { Class.forName(directionPath),
				Class.forName(piecePath) };
		testConstructorExists(Class.forName(slideCellPath), inputs);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test(timeout = 1000)
	public void testConstructorSlideCellConstructor1Initialization()
			throws Exception {

		Constructor<?> constructor = Class.forName(slideCellPath)
				.getConstructor(Class.forName(directionPath));

		Object myObj = constructor.newInstance(Enum.valueOf(
				(Class<Enum>) Class.forName(directionPath), "UP"));
		String[] names = { "direction", "piece" };
		Object[] values = {
				Enum.valueOf((Class<Enum>) Class.forName(directionPath), "UP"),
				null };

		testConstructorInitialization(myObj, names, values);

		myObj = constructor.newInstance(Enum.valueOf(
				(Class<Enum>) Class.forName(directionPath), "DOWN"));
		String[] names1 = { "direction", "piece" };
		Object[] values1 = {
				Enum.valueOf((Class<Enum>) Class.forName(directionPath), "DOWN"),
				null };

		testConstructorInitialization(myObj, names1, values1);

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test(timeout = 1000)
	public void testConstructorSlideCellConstructor2Initialization()
			throws Exception {

		Constructor<?> constructor = Class.forName(slideCellPath)
				.getConstructor(Class.forName(directionPath),
						Class.forName(piecePath));

		Constructor<?> playerConstructor1 = Class.forName(playerPath)
				.getConstructor(String.class);
		Object p1 = playerConstructor1.newInstance("Player1");
		Constructor<?> playerConstructor2 = Class.forName(playerPath)
				.getConstructor(String.class);
		Object p2 = playerConstructor2.newInstance("Player2");

		Constructor<?> gameConstructor = Class.forName(gamePath)
				.getConstructor(Class.forName(playerPath),
						Class.forName(playerPath));
		Object g = gameConstructor.newInstance(p1, p2);

		Constructor<?> medicConstructor = Class.forName(medicPath)
				.getConstructor(Class.forName(playerPath),
						Class.forName(gamePath), String.class);
		Object med = medicConstructor.newInstance(p1, g, "piece1");

		Object myObj = constructor.newInstance(Enum.valueOf(
				(Class<Enum>) Class.forName(directionPath), "DOWN"), med);
		String[] names = { "direction", "piece" };
		Object[] values = {
				Enum.valueOf((Class<Enum>) Class.forName(directionPath), "DOWN"),
				med };

		testConstructorInitialization(myObj, names, values);

		myObj = constructor.newInstance(Enum.valueOf(
				(Class<Enum>) Class.forName(directionPath), "LEFT"), med);
		String[] names1 = { "direction", "piece" };
		Object[] values1 = {
				Enum.valueOf((Class<Enum>) Class.forName(directionPath), "LEFT"),
				med };
		testConstructorInitialization(myObj, names1, values1);
	}

	@Test(timeout = 100)
	public void testInstanceVariableSlideCellDirectionGetter() throws Exception {
		testGetterMethodExistsInClass(Class.forName(slideCellPath),
				"getDirection", Class.forName(directionPath));
	}

	@Test(timeout = 100)
	public void testInstanceVariableSlideCellDirectionSetter() throws Exception {
		testSetterMethodExistsInClass(Class.forName(slideCellPath),
				"setDirection", Class.forName(directionPath), false);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test(timeout = 100)
	public void testInstanceVariableSlideCellDirectionGetterLogic()
			throws Exception {
		Constructor<?> constructor = Class.forName(slideCellPath)
				.getConstructor(Class.forName(directionPath));

		Object myObj = constructor.newInstance(Enum.valueOf(
				(Class<Enum>) Class.forName(directionPath), "LEFT"));

		testGetterLogic(myObj, "direction", Enum.valueOf(
				(Class<Enum>) Class.forName(directionPath), "LEFT"));

		myObj = constructor.newInstance(Enum.valueOf(
				(Class<Enum>) Class.forName(directionPath), "UPLEFT"));

		testGetterLogic(myObj, "direction", Enum.valueOf(
				(Class<Enum>) Class.forName(directionPath), "UPLEFT"));
	}

	@Test(timeout = 100)
	public void testClassIsSubclassBlockCell() throws Exception {
		testClassIsSubclass(Class.forName(blockCellPath),
				Class.forName(cellPath));
	}

	@Test(timeout = 100)
	public void testInstanceVariableBlockCellPiece() throws Exception {
		testInstanceVariableIsPresent(Class.forName(blockCellPath), "piece",
				false);
	}

	@Test(timeout = 100)
	public void testInstanceVariableBlockCellBlocks() throws Exception {
		testInstanceVariableIsPresent(Class.forName(blockCellPath), "blocks",
				true);
		testInstanceVariableIsPrivate(Class.forName(blockCellPath), "blocks");
	}

	@Test(timeout = 100)
	public void testConstructorBlockCell() throws Exception {
		@SuppressWarnings("rawtypes")
		Class[] inputs = {};
		testConstructorExists(Class.forName(blockCellPath), inputs);
	}

	@Test(timeout = 100)
	public void testConstructorBlockCellInitialization() throws Exception {
		Constructor<?> constructor = Class.forName(blockCellPath)
				.getConstructor();
		Object myObj = constructor.newInstance();
		String[] names = { "blocks" };
		Object[] values = { 3 };
		testConstructorInitialization(myObj, names, values);
	}

	@Test(timeout = 100)
	public void testInstanceVariableBlockCellBlocksGetter() throws Exception {
		testGetterMethodExistsInClass(Class.forName(blockCellPath),
				"getBlocks", int.class);
	}

	@Test(timeout = 100)
	public void testInstanceVariableBlockCellBlockSetter() throws Exception {
		testSetterMethodExistsInClass(Class.forName(blockCellPath),
				"setBlocks", int.class, true);
	}

	@Test(timeout = 100)
	public void testInstanceVariableBlockCellBlocksGetterLogic()
			throws Exception {
		Constructor<?> constructor = Class.forName(blockCellPath)
				.getConstructor();

		Object myObj = constructor.newInstance();
		int random = (int) (Math.random() * 40) + 10;
		testGetterLogic(myObj, "blocks", random);
	}

	@Test(timeout = 100)
	public void testInstanceVariableBlockCellBlocksSetterLogic()
			throws Exception {
		Constructor<?> constructor = Class.forName(blockCellPath)
				.getConstructor();

		Object myObj = constructor.newInstance();
		int random = (int) (Math.random() * 40) + 10;
		testSetterLogic(myObj, "blocks", random, int.class);
	}

	@Test(timeout = 100)
	public void testClassIsSubclassUnallowedMovementException()
			throws Exception {
		testClassIsSubclass(Class.forName(unAllowedMoveInBlockPath),
				Class.forName(invalidMovementExceptionPath));
	}

	@Test(timeout = 1000)
	public void testConstructorUnallowedMovementExceptionConstructor1()
			throws Exception {
		@SuppressWarnings("rawtypes")
		Class[] inputs = { Piece.class, Direction.class };
		testConstructorExists(Class.forName(unAllowedMoveInBlockPath), inputs);
	}

	@Test(timeout = 1000)
	public void testConstructorUnallowedMovementExceptionConstructor2()
			throws Exception {
		@SuppressWarnings("rawtypes")
		Class[] inputs = { String.class, Piece.class, Direction.class };
		testConstructorExists(Class.forName(unAllowedMoveInBlockPath), inputs);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test(timeout = 1000)
	public void testConstructorUnallowedMovementExceptionConstructor1Initialization()
			throws Exception {
		Constructor<?> constructor = Class.forName(unAllowedMoveInBlockPath)
				.getConstructor(Class.forName(piecePath),
						Class.forName(directionPath));

		Constructor<?> playerConstructor1 = Class.forName(playerPath)
				.getConstructor(String.class);
		Object p1 = playerConstructor1.newInstance("Player1");
		Constructor<?> playerConstructor2 = Class.forName(playerPath)
				.getConstructor(String.class);
		Object p2 = playerConstructor2.newInstance("Player2");

		Constructor<?> gameConstructor = Class.forName(gamePath)
				.getConstructor(Class.forName(playerPath),
						Class.forName(playerPath));
		Object g = gameConstructor.newInstance(p1, p2);

		Constructor<?> medicConstructor = Class.forName(medicPath)
				.getConstructor(Class.forName(playerPath),
						Class.forName(gamePath), String.class);
		Object med = medicConstructor.newInstance(p1, g, "piece1");

		Object myObj = constructor.newInstance(med,
				Enum.valueOf((Class<Enum>) Class.forName(directionPath), "UP"));
		String[] names = { "trigger", "direction" };
		Object[] values = { med,
				Enum.valueOf((Class<Enum>) Class.forName(directionPath), "UP") };

		testConstructorInitialization(myObj, names, values);

		myObj = constructor.newInstance(med, Enum.valueOf(
				(Class<Enum>) Class.forName(directionPath), "RIGHT"));
		String[] names1 = { "trigger", "direction" };
		Object[] values1 = {
				med,
				Enum.valueOf((Class<Enum>) Class.forName(directionPath),
						"RIGHT") };

		testConstructorInitialization(myObj, names1, values1);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test(timeout = 1000)
	public void testConstructorUnallowedMovementExceptionConstructor2Initialization()
			throws Exception {

		Constructor<?> constructor = Class.forName(unAllowedMoveInBlockPath)
				.getConstructor(String.class, Class.forName(piecePath),
						Class.forName(directionPath));

		Constructor<?> playerConstructor1 = Class.forName(playerPath)
				.getConstructor(String.class);
		Object p1 = playerConstructor1.newInstance("Player1");
		Constructor<?> playerConstructor2 = Class.forName(playerPath)
				.getConstructor(String.class);
		Object p2 = playerConstructor2.newInstance("Player2");

		Constructor<?> gameConstructor = Class.forName(gamePath)
				.getConstructor(Class.forName(playerPath),
						Class.forName(playerPath));
		Object g = gameConstructor.newInstance(p1, p2);

		Constructor<?> medicConstructor = Class.forName(medicPath)
				.getConstructor(Class.forName(playerPath),
						Class.forName(gamePath), String.class);
		Object med = medicConstructor.newInstance(p1, g, "piece1");

		int random = (int) (Math.random() * 40) + 10;
		Object myObj = constructor.newInstance("error" + random, med, Enum
				.valueOf((Class<Enum>) Class.forName(directionPath), "RIGHT"));
		String[] names = { "trigger", "direction" };
		Object[] values = {
				med,
				Enum.valueOf((Class<Enum>) Class.forName(directionPath),
						"RIGHT") };

		assertEquals("The constructor of the "
				+ myObj.getClass().getSimpleName()
				+ " class should initialize the instance variable \""
				+ "message" + "\" correctly.", "error" + random,
				((Exception) myObj).getMessage());
		testConstructorInitialization(myObj, names, values);

		myObj = constructor.newInstance("error", med, Enum.valueOf(
				(Class<Enum>) Class.forName(directionPath), "LEFT"));
		String[] names1 = { "trigger", "direction" };
		Object[] values1 = {
				med,
				Enum.valueOf((Class<Enum>) Class.forName(directionPath), "LEFT") };

		assertEquals("The constructor of the "
				+ myObj.getClass().getSimpleName()
				+ " class should initialize the instance variable \""
				+ "message" + "\" correctly.", "error",
				((Exception) myObj).getMessage());
		testConstructorInitialization(myObj, names1, values1);

	}

	/*************** Helper Methods ***************/

	private void testInstanceVariableIsPresent(Class<?> aClass, String varName,
			boolean implementedVar) throws SecurityException {

		boolean thrown = false;
		try {
			aClass.getDeclaredField(varName);
		} catch (NoSuchFieldException e) {
			thrown = true;
		}
		if (implementedVar) {
			assertFalse("There should be \"" + varName
					+ "\" instance variable in class " + aClass.getSimpleName()
					+ ".", thrown);
		} else {
			assertTrue(
					"The instance variable \"" + varName
							+ "\" should not be declared in class "
							+ aClass.getSimpleName() + ".", thrown);
		}
	}

	private void testInstanceVariableIsPrivate(Class<?> aClass, String varName)
			throws NoSuchFieldException, SecurityException {
		Field f = aClass.getDeclaredField(varName);
		assertEquals("The \"" + varName + "\" instance variable in class "
				+ aClass.getSimpleName()
				+ " should not be accessed outside that class.", 2,
				f.getModifiers());
	}

	private void testGetterMethodExistsInClass(Class<?> aClass,
			String methodName, Class<?> returnedType) {
		Method m = null;
		boolean found = true;
		try {
			m = aClass.getDeclaredMethod(methodName);
		} catch (NoSuchMethodException e) {
			found = false;
		}

		String varName = "";
		if (returnedType == boolean.class)
			varName = methodName.substring(2).toLowerCase();
		else
			varName = methodName.substring(3).toLowerCase();

		assertTrue("The \"" + varName + "\" instance variable in class "
				+ aClass.getSimpleName() + " is a READ variable.", found);
		assertTrue("Incorrect return type for " + methodName + " method in "
				+ aClass.getSimpleName() + " class.", m.getReturnType()
				.isAssignableFrom(returnedType));
	}

	private void testSetterMethodExistsInClass(Class<?> aClass,
			String methodName, Class<?> inputType, boolean writeVariable) {

		Method[] methods = aClass.getDeclaredMethods();
		String varName = methodName.substring(3).toLowerCase();
		if (writeVariable) {
			assertTrue("The \"" + varName + "\" instance variable in class "
					+ aClass.getSimpleName() + " is a WRITE variable.",
					containsMethodName(methods, methodName));
		} else {
			assertFalse("The \"" + varName + "\" instance variable in class "
					+ aClass.getSimpleName() + " is not a WRITE variable.",
					containsMethodName(methods, methodName));
			return;
		}
		Method m = null;
		boolean found = true;
		try {
			m = aClass.getDeclaredMethod(methodName, inputType);
		} catch (NoSuchMethodException e) {
			found = false;
		}

		assertTrue(aClass.getSimpleName() + " class should have " + methodName
				+ " method that takes one " + inputType.getSimpleName()
				+ " parameter.", found);

		assertTrue("Incorrect return type for " + methodName + " method in "
				+ aClass.getSimpleName() + ".",
				m.getReturnType().equals(Void.TYPE));

	}

	private static boolean containsMethodName(Method[] methods, String name) {
		for (Method method : methods) {
			if (method.getName().equals(name))
				return true;
		}
		return false;
	}

	private void testConstructorExists(Class<?> aClass, Class<?>[] inputs) {
		boolean thrown = false;
		try {
			aClass.getConstructor(inputs);
		} catch (NoSuchMethodException e) {
			thrown = true;
		}

		if (inputs.length > 0) {
			String msg = "";
			int i = 0;
			do {
				msg += inputs[i].getSimpleName() + " and ";
				i++;
			} while (i < inputs.length);

			msg = msg.substring(0, msg.length() - 4);

			assertFalse(
					"Missing constructor with " + msg + " parameter"
							+ (inputs.length > 1 ? "s" : "") + " in "
							+ aClass.getSimpleName() + " class.",

					thrown);
		} else
			assertFalse(
					"Missing constructor with zero parameters in "
							+ aClass.getSimpleName() + " class.",

					thrown);

	}

	private void testConstructorInitialization(Object createdObject,
			String[] names, Object[] values) throws NoSuchMethodException,
			SecurityException, IllegalArgumentException, IllegalAccessException {

		for (int i = 0; i < names.length; i++) {

			Field f = null;
			Class<?> curr = createdObject.getClass();
			String currName = names[i];
			Object currValue = values[i];

			while (f == null) {

				if (curr == Object.class)
					fail("Class " + createdObject.getClass().getSimpleName()
							+ " should have the instance variable \""
							+ currName + "\".");
				try {
					f = curr.getDeclaredField(currName);
				} catch (NoSuchFieldException e) {
					curr = curr.getSuperclass();
				}

			}

			f.setAccessible(true);

			assertEquals("The constructor of the "
					+ createdObject.getClass().getSimpleName()
					+ " class should initialize the instance variable \""
					+ currName + "\" correctly.", currValue,
					f.get(createdObject));

		}

	}

	private void testGetterLogic(Object createdObject, String name, Object value)
			throws Exception {

		Field f = null;
		Class<?> curr = createdObject.getClass();

		while (f == null) {

			if (curr == Object.class)
				fail("Class " + createdObject.getClass().getSimpleName()
						+ " should have the instance variable \"" + name
						+ "\".");
			try {
				f = curr.getDeclaredField(name);
			} catch (NoSuchFieldException e) {
				curr = curr.getSuperclass();
			}

		}

		f.setAccessible(true);
		f.set(createdObject, value);

		Character c = name.charAt(0);

		String methodName = "get" + Character.toUpperCase(c)
				+ name.substring(1, name.length());

		if (value.getClass().equals(Boolean.class))
			methodName = "is" + Character.toUpperCase(c)
					+ name.substring(1, name.length());

		Method m = createdObject.getClass().getMethod(methodName);
		assertEquals("The method \"" + methodName + "\" in class "
				+ createdObject.getClass().getSimpleName()
				+ " should return the correct value of variable \"" + name
				+ "\".", value, m.invoke(createdObject));

	}

	private void testSetterLogic(Object createdObject, String name,
			Object value, Class<?> type) throws Exception {

		Field f = null;
		Class<?> curr = createdObject.getClass();

		while (f == null) {

			if (curr == Object.class)
				fail("Class " + createdObject.getClass().getSimpleName()
						+ " should have the instance variable \"" + name
						+ "\".");
			try {
				f = curr.getDeclaredField(name);
			} catch (NoSuchFieldException e) {
				curr = curr.getSuperclass();
			}

		}

		f.setAccessible(true);

		Character c = name.charAt(0);
		String methodName = "set" + Character.toUpperCase(c)
				+ name.substring(1, name.length());
		Method m = createdObject.getClass().getMethod(methodName, type);
		m.invoke(createdObject, value);

		assertEquals(
				"The method \"" + methodName + "\" in class "
						+ createdObject.getClass().getSimpleName()
						+ " should set the correct value of variable \"" + name
						+ "\".", value, f.get(createdObject));

	}

	private void testClassIsSubclass(Class<?> subClass, Class<?> superClass) {
		assertEquals(
				subClass.getSimpleName() + " class should be a subclass from "
						+ superClass.getSimpleName() + ".", superClass,
				subClass.getSuperclass());
	}

}
