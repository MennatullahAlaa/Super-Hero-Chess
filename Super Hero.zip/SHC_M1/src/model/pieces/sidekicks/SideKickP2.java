package model.pieces.sidekicks;

import exceptions.OccupiedCellException;
import exceptions.UnallowedMovementException;
import model.game.Direction;
import model.game.Game;
import model.pieces.Piece;
import model.pieces.heroes.Armored;
import model.pieces.heroes.Medic;
import model.pieces.heroes.Ranged;
import model.pieces.heroes.Speedster;
import model.pieces.heroes.Super;
import model.pieces.heroes.Tech;

public class SideKickP2 extends SideKick {

	public SideKickP2(Game game, String name) {
		super(game.getPlayer2(), game, name);
	}
	/*public void move(Direction r) throws UnallowedMovementException ,OccupiedCellException{
    	//throws UnallowedMovementException , InvalidMovementException
    	int a=this.getPosI();
    	int b=this.getPosJ();
    	
    	if(r==Direction.DOWN){
    		
    		this.moveDown();
    	//	this.attack(this.getGame().getBoard()[++a][b].getPiece());
    		
    		
    		
   
    	}
    	if(r==Direction.DOWNLEFT){
    		//this.attack(this.getGame().getBoard()[--a][--b].getPiece());
    		this.moveDownLeft();
    	//	this.attack(this.getGame().getBoard()[--a][--b].getPiece());
    	
    	}
    	if(r==Direction.DOWNRIGHT){
    		//this.attack(this.getGame().getBoard()[--a][++b].getPiece());
    		this.moveDownRight();
    		//this.attack(this.getGame().getBoard()[--a][++b].getPiece());
    		
    	}
    	if(r==Direction.LEFT){
    		//this.attack(this.getGame().getBoard()[a][--b].getPiece());
    		this.moveLeft();
    		//this.attack(this.getGame().getBoard()[a][--b].getPiece());
    		
    	}
    	if(r==Direction.RIGHT){
    		this.moveRight();
    		//this.attack(this.getGame().getBoard()[a][++b].getPiece());
    		
    	}
    	if(r==Direction.UP){
    		throw new UnallowedMovementException(this,Direction.UP);
    		//this.moveUp();
    		//this.attack(this.getGame().getBoard()[++a][b].getPiece());
    		
    	}
    	if(r==Direction.UPLEFT){
    		throw new UnallowedMovementException(this,Direction.UPLEFT);

    		//this.moveUpLeft();
    		//.attack(this.getGame().getBoard()[++a][--b].getPiece());
    		
    	}
    	if(r==Direction.UPRIGHT){
    		throw new UnallowedMovementException(this,Direction.UPRIGHT);

    		//this.moveUpRight();
    		//this.attack(this.getGame().getBoard()[++a][--b].getPiece());
    		
    	}
    	this.getGame().switchTurns();
    	
    	
    }*/
	public void moveUp()throws UnallowedMovementException,OccupiedCellException{
		throw new UnallowedMovementException(this,Direction.UP);
	}
	public void moveUpRight()throws UnallowedMovementException,OccupiedCellException{
		throw new UnallowedMovementException(this,Direction.UPRIGHT);
	}
	public void moveUpLeft()throws UnallowedMovementException,OccupiedCellException{
		throw new UnallowedMovementException(this,Direction.UPLEFT);
	}
/*public void attack(Piece target){
		
		if(target.getName().equals("Armored")){
			if(((Armored)target).isArmorUp()==true){
				((Armored)target).setArmorUp(false);	
			}
			else{
				super.attack(target);
				this.getGame().getBoard()[this.getPosI()][this.getPosJ()].setPiece(new Armored(this.getOwner(),this.getGame(),"Armored"));
			}
		}
		if(target.getName().equals("Tech")){
			super.attack(target);
			this.getGame().getBoard()[this.getPosI()][this.getPosJ()].setPiece(new Tech(this.getOwner(),this.getGame(),"Tech"));
			
		}
		if(target.getName().equals("Medic")){
			super.attack(target);
			this.getGame().getBoard()[this.getPosI()][this.getPosJ()].setPiece(new Medic(this.getOwner(),this.getGame(),"Medic"));
			
		}
		if(target.getName().equals("Speedster")){
			super.attack(target);
			this.getGame().getBoard()[this.getPosI()][this.getPosJ()].setPiece(new Speedster(this.getOwner(),this.getGame(),"Speedster"));
			
		}
		if(target.getName().equals("Super")){
			super.attack(target);
			this.getGame().getBoard()[this.getPosI()][this.getPosJ()].setPiece(new Super(this.getOwner(),this.getGame(),"Super"));
			
		}
		if(target.getName().equals("Ranged")){
			super.attack(target);
			this.getGame().getBoard()[this.getPosI()][this.getPosJ()].setPiece(new Ranged(this.getOwner(),this.getGame(),"Ranged"));
			
		}
		if(target.getName().equals("SideKick")){
			if(this.getOwner().getSideKilled()%2!=0){
				((target.getGame().getBoard())[target.getPosI()][target.getPosJ()]).setPiece(null);
				
				int temp=this.getOwner().getPayloadPos();
				temp++;
				this.getOwner().setPayloadPos(temp);	
				
			}
			int temp1=this.getOwner().getSideKilled();
			temp1++;
			this.getOwner().setSideKilled(temp1);
			
			this.getOwner().getDeadCharacters().add(target);
			
			//this.getGame().checkWinner();
		}
		this.getGame().checkWinner();
		this.getGame().switchTurns();
			
		}*/

}
