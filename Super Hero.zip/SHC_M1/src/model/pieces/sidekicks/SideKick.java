package model.pieces.sidekicks;

import model.game.Game;
import model.game.Player;
import model.pieces.Piece;
import model.pieces.heroes.Armored;
import model.pieces.heroes.Medic;
import model.pieces.heroes.Ranged;
import model.pieces.heroes.Speedster;
import model.pieces.heroes.Super;
import model.pieces.heroes.Tech;

public abstract class SideKick extends Piece {

	public SideKick(Player player, Game game, String name) {
		super(player, game, name);
	}

	@Override
	public String toString() {
		return "K";
	}
	
	public void attack(Piece target){
	
		if(target instanceof Armored){
			if(((Armored)target).isArmorUp()==true){
				((Armored)target).setArmorUp(false);
				return;
			}
			else{
				//super.attack(target);
				this.getGame().getCellAt(target.getPosI(), target.getPosJ()).setPiece(null);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(new Armored(this.getOwner(),this.getGame(),"Armored"));
				//this.getGame().getBoard()[this.getPosI()][this.getPosJ()].setPiece(null);
			}
		}
		if(target instanceof Tech){
			//super.attack(target);
			this.getGame().getCellAt(target.getPosI(), target.getPosJ()).setPiece(null);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(new Tech(this.getOwner(),this.getGame(),"Tech"));
			
		}
		if(target instanceof Medic){
			//super.attack(target);
			this.getGame().getCellAt(target.getPosI(), target.getPosJ()).setPiece(null);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(new Medic(this.getOwner(),this.getGame(),"Medic"));
			
		}
		if(target instanceof Speedster){
			//super.attack(target);
			this.getGame().getCellAt(target.getPosI(), target.getPosJ()).setPiece(null);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(new Speedster(this.getOwner(),this.getGame(),"Speedster"));
			
		}
		if(target instanceof Super){
			//super.attack(target);
			this.getGame().getCellAt(target.getPosI(), target.getPosJ()).setPiece(null);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(new Super(this.getOwner(),this.getGame(),"Super"));
			
		}
		if(target instanceof Ranged){
			//super.attack(target);
			this.getGame().getCellAt(target.getPosI(), target.getPosJ()).setPiece(null);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(new Ranged(this.getOwner(),this.getGame(),"Ranged"));
			
		}
		if(target instanceof SideKick){
			this.getGame().getCellAt(target.getPosI(), target.getPosJ()).setPiece(null);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(this);
			int temp1=this.getOwner().getSideKilled();
			temp1++;
			this.getOwner().setSideKilled(temp1);
			
			if(this.getOwner().getSideKilled()==2){
				int temp=this.getOwner().getPayloadPos();
				temp++;
				this.getOwner().setPayloadPos(temp);
				this.getOwner().setSideKilled(0);
				
			}
		}
		else{
			int temp=this.getOwner().getPayloadPos();
			temp++;
			this.getOwner().setPayloadPos(temp);
			
		}
		//this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
		//this.getGame().getCellAt(target.getPosI(), target.getPosJ()).getPiece().setPosI(target.getPosI());
		//this.getGame().getCellAt(target.getPosI(), target.getPosJ()).getPiece().setPosJ(target.getPosJ());
		
		this.getOwner().getDeadCharacters().add(target);
		this.getGame().checkWinner();
		//this.getGame().switchTurns();
			
		}
}
