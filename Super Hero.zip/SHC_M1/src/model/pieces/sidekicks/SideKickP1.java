package model.pieces.sidekicks;

import exceptions.OccupiedCellException;
import exceptions.UnallowedMovementException;
import model.game.Direction;
import model.game.Game;
import model.pieces.Piece;
import model.pieces.heroes.Armored;
import model.pieces.heroes.Medic;
import model.pieces.heroes.Ranged;
import model.pieces.heroes.Speedster;
import model.pieces.heroes.Super;
import model.pieces.heroes.Tech;

public class SideKickP1 extends SideKick {

	public SideKickP1(Game game, String name) {
		super(game.getPlayer1(), game, name);
	}
	
	public void moveDown()throws UnallowedMovementException,OccupiedCellException{
		/*if((this.getGame().getBoard()[this.getDown(this.getPosI())][this.getPosJ()].getPiece()!=null)&&this.getOwner().equals(this.getGame().getBoard()[this.getDown(this.getPosI())][this.getPosJ()].getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.DOWN);
        }*/
		throw new UnallowedMovementException(this,Direction.DOWN);
	}
	public void moveDownRight()throws UnallowedMovementException,OccupiedCellException{
		/*int a=this.getDown(this.getPosI());
    	int b=this.getRight(this.getPosJ());
		if((this.getGame().getBoard()[a][b].getPiece()!=null)&&this.getOwner().equals(this.getGame().getBoard()[a][b].getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.DOWNRIGHT);
        }*/
		throw new UnallowedMovementException(this,Direction.DOWNRIGHT);
	}
	public void moveDownLeft()throws UnallowedMovementException,OccupiedCellException{
		/*int a=this.getDown(this.getPosI());
    	int b=this.getLeft(this.getPosJ());
		if((this.getGame().getBoard()[a][b].getPiece()!=null)&&this.getOwner().equals(this.getGame().getBoard()[a][b].getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.DOWNLEFT);
        }*/
		throw new UnallowedMovementException(this,Direction.DOWNLEFT);
	}
	
/*public void attack(Piece target){
		
		if(target.getName().equals("Armored")){
			if(((Armored)target).isArmorUp()==true){
				((Armored)target).setArmorUp(false);	
			}
			else{
				super.attack(target);
				this.getGame().getBoard()[this.getPosI()][this.getPosJ()].setPiece(new Armored(this.getOwner(),this.getGame(),"Armored"));
			}
		}
		if(target.getName().equals("Tech")){
			super.attack(target);
			this.getGame().getBoard()[this.getPosI()][this.getPosJ()].setPiece(new Tech(this.getOwner(),this.getGame(),"Tech"));
			
		}
		if(target.getName().equals("Medic")){
			super.attack(target);
			this.getGame().getBoard()[this.getPosI()][this.getPosJ()].setPiece(new Medic(this.getOwner(),this.getGame(),"Medic"));
			
		}
		if(target.getName().equals("Speedster")){
			super.attack(target);
			this.getGame().getBoard()[this.getPosI()][this.getPosJ()].setPiece(new Speedster(this.getOwner(),this.getGame(),"Speedster"));
			
		}
		if(target.getName().equals("Super")){
			super.attack(target);
			this.getGame().getBoard()[this.getPosI()][this.getPosJ()].setPiece(new Super(this.getOwner(),this.getGame(),"Super"));
			
		}
		if(target.getName().equals("Ranged")){
			super.attack(target);
			this.getGame().getBoard()[this.getPosI()][this.getPosJ()].setPiece(new Ranged(this.getOwner(),this.getGame(),"Ranged"));
			
		}
		if(target.getName().equals("SideKick")){
			if(this.getOwner().getSideKilled()%2!=0){
				((target.getGame().getBoard())[target.getPosI()][target.getPosJ()]).setPiece(null);
				
				int temp=this.getOwner().getPayloadPos();
				temp++;
				this.getOwner().setPayloadPos(temp);	
				
			}
			int temp1=this.getOwner().getSideKilled();
			temp1++;
			this.getOwner().setSideKilled(temp1);
			
			this.getOwner().getDeadCharacters().add(target);
			
			//this.getGame().checkWinner();
		}
		this.getGame().checkWinner();
		this.getGame().switchTurns();
			
		}*/

}
