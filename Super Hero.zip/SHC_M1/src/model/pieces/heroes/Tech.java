package model.pieces.heroes;

import java.awt.Point;

import exceptions.InvalidPowerDirectionException;
import exceptions.InvalidPowerTargetException;
import exceptions.PowerAlreadyUsedException;
import exceptions.UnallowedMovementException;
import exceptions.WrongTurnException;
import model.game.Direction;
import model.game.Game;
import model.game.Player;
import model.pieces.Piece;

public class Tech extends ActivatablePowerHero {

	public Tech(Player player, Game game, String name) {
		super(player, game, name);
	}

	@Override
	public String toString() {
		return "T";
	}
	
	public void moveRight()throws UnallowedMovementException{
		throw new UnallowedMovementException(this,Direction.RIGHT);
	}
	public void moveLeft()throws UnallowedMovementException{
		throw new UnallowedMovementException(this,Direction.LEFT);
	}
	public void moveDown()throws UnallowedMovementException{
		throw new UnallowedMovementException(this,Direction.DOWN);
	}
	public void moveUp()throws UnallowedMovementException{
		throw new UnallowedMovementException(this,Direction.UP);
	}
	
	public void usePower(Direction d,Piece target,Point newPos)throws PowerAlreadyUsedException,InvalidPowerDirectionException,WrongTurnException,InvalidPowerTargetException{
       super.usePower(d,target,newPos);
		if ((target.getOwner().equals(this.getGame().getCurrentPlayer()))&& (isPointNull(newPos)==false)){
			if ((this.getGame().getCellAt((int)(newPos.getX()),(int)(newPos.getY()))).getPiece()!=null){
				throw new InvalidPowerTargetException("The target location is occupied",this,target);
			}
			
			else if (this.getGame().getCellAt((int)(newPos.getX()),(int)(newPos.getY())).getPiece()==null){
			this.getGame().getCellAt((int)(newPos.getX()),(int)(newPos.getY())).setPiece(target);
			target.getGame().getCellAt(target.getPosI(),target.getPosJ()).setPiece(null);
			target.setPosI((int)(newPos.getX()));
			target.setPosJ((int)(newPos.getY()));
			
			}
			
		}
		else if ((target.getOwner().equals(this.getGame().getCurrentPlayer()))==false&& (isPointNull(newPos)==false)){
			throw new InvalidPowerTargetException("The target does not belong to the same team",this,target);
		}
		
		
		if((target.getOwner().equals(this.getGame().getCurrentPlayer()))&& (isPointNull(newPos)==true)){
			if (target instanceof ActivatablePowerHero){
				if (((ActivatablePowerHero)target).isPowerUsed()==true){
					((ActivatablePowerHero)target).setPowerUsed(false);
					
					 }
				
				else{
					throw new InvalidPowerTargetException("The target piece did not use the power yet",this,target);
				
				}
				
			}
			else if(target instanceof Armored){
				if (((Armored)target).isArmorUp()==false){
					((Armored)target).setArmorUp(true);
					
					}
				else {
					throw new InvalidPowerTargetException("The target piece did not use its power yet",this,target);
				}
			}
		}
		else if ((target.getOwner().equals(this.getGame().getCurrentPlayer())==false)){
			if (target instanceof ActivatablePowerHero){
				if (((ActivatablePowerHero)target).isPowerUsed()==false){
					((ActivatablePowerHero)target).setPowerUsed(true);
					
				}
					else{
						throw new InvalidPowerTargetException("The enemy has already used its power, & cannot be hacked",this,target);
					}
					
			}
			else if (target instanceof Armored){
				if (((Armored)target).isArmorUp()==true){
					((Armored)target).setArmorUp(false);
					
				}
				else {
					throw new InvalidPowerTargetException("The enemy has already used its power & it cannot be hacked",this,target);
				}
				
			}
			
			
		}
		this.setPowerUsed(true);
	    
	}		
	
	public boolean isPointNull(Point x){
		if(x==null){
			return true;
		}
		else{
			return false;
		}
	}
	
	
	
}
