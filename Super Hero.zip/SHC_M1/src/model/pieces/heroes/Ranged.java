package model.pieces.heroes;

import java.awt.Point;

import exceptions.InvalidPowerDirectionException;
import exceptions.InvalidPowerTargetException;
import exceptions.OccupiedCellException;
import exceptions.PowerAlreadyUsedException;
import exceptions.UnallowedMovementException;
import exceptions.WrongTurnException;
import model.game.Direction;
import model.game.Game;
import model.game.Player;
import model.pieces.Piece;

public class Ranged extends ActivatablePowerHero {

	public Ranged(Player player, Game game, String name) {
		super(player, game, name);
	}

	public String toString() {
		return "R";
	}
	
	
	
	public void usePower(Direction d,Piece target,Point newPos)throws InvalidPowerTargetException,PowerAlreadyUsedException,InvalidPowerDirectionException,WrongTurnException{
		
		super.usePower(d, target, newPos);
		
		if(d==Direction.UPLEFT ){
			throw new InvalidPowerDirectionException("This direction is not allowed",this,Direction.UPLEFT);
		}
		if(d==Direction.UPRIGHT ){
			throw new InvalidPowerDirectionException("This direction is not allowed",this,Direction.UPRIGHT);
		}
		if(d==Direction.DOWNLEFT ){
			throw new InvalidPowerDirectionException("This direction is not allowed",this,Direction.DOWNLEFT);
		}
		if(d==Direction.DOWNRIGHT){
			throw new InvalidPowerDirectionException("This direction is not allowed",this,Direction.DOWNLEFT);
		}
		
		boolean check=true;
		int x=this.getPosI();
		int y=this.getPosJ();
		
		
		if(d==Direction.RIGHT){
			int z=y+1;
			while(z<6){
				if((this.getGame().getCellAt(x,z).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(x,z).getPiece().getOwner())){
					throw new InvalidPowerDirectionException("This direction will result in hitting a friendly piece",this,Direction.RIGHT);
				}
				else{
					if(this.getGame().getCellAt(x,z).getPiece()==null){
						z++;
					}
					else{
						this.attack(this.getGame().getCellAt(x,z).getPiece());
						check=false;
						break;
					}
				}
			}
			if (check==true){
				throw new InvalidPowerDirectionException("This direction will result in hitting no enemies",this,Direction.RIGHT);
		}
		}
		if(d==Direction.LEFT){
			int w=y-1;
			while(w>-1){
				if((this.getGame().getCellAt(x,w).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(x,w).getPiece().getOwner())){
					throw new InvalidPowerDirectionException("This direction will result in hitting a friendly piece",this,Direction.LEFT);
				}
				else{
					if(this.getGame().getCellAt(x,w).getPiece()==null){
						w--;
					}
					else{
						
						this.attack(this.getGame().getCellAt(x,w).getPiece());
						check=false;
						break;
					}
				}
			}
			if (check==true){
				throw new InvalidPowerDirectionException("This direction will result in hitting no enemies",this,Direction.LEFT);
		}
		}	
		if(d==Direction.UP){
			int a=x-1;
			int b=x+1;
			while(a>-1){
				if((this.getGame().getCellAt(a,y).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(a,y).getPiece().getOwner())){
					throw new InvalidPowerDirectionException("This direction will result in hitting a friendly piece",this,Direction.UP);
				}
				else{
					if(this.getGame().getCellAt(a,y).getPiece()==null){
						a--;
					}
					else{
						
						this.attack(this.getGame().getCellAt(a,y).getPiece());
						check= false;
						break;
					}
				}
			}
			if (check==true){
				throw new InvalidPowerDirectionException("This direction will result in hitting no enemies",this,Direction.UP);
		}
		}
		if(d==Direction.DOWN){
			int b=x+1;
			while(b<7){
				if((this.getGame().getCellAt(b,y).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(b,y).getPiece().getOwner())){
					throw new InvalidPowerDirectionException("This direction will result in hitting a friendly piece",this,Direction.DOWN);
				}
				else{
					if(this.getGame().getCellAt(b,y).getPiece()==null){
						b++;
					}
					else{
						
						this.attack(this.getGame().getCellAt(b,y).getPiece());
						check=false;
						break;
					}
				}
			}
			if (check==true){
				throw new InvalidPowerDirectionException("This direction will result in hitting no enemies",this, Direction.DOWN);
		}
		
		}
		
		this.setPowerUsed(true);
		this.getGame().switchTurns();
	}
}

		