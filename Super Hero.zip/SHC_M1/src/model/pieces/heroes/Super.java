package model.pieces.heroes;

import java.awt.Point;

import exceptions.InvalidPowerDirectionException;
import exceptions.InvalidPowerTargetException;
import exceptions.OccupiedCellException;
import exceptions.PowerAlreadyUsedException;
import exceptions.UnallowedMovementException;
import exceptions.WrongTurnException;
import model.game.Direction;
import model.game.Game;
import model.game.Player;
import model.pieces.Piece;
import model.pieces.sidekicks.SideKick;

public class Super extends ActivatablePowerHero {

	public Super(Player player, Game game, String name) {
		super(player, game, name);
	}

	@Override
	public String toString() {
		
	return "P";
	}
	public void moveUpRight()throws UnallowedMovementException{
		throw new UnallowedMovementException(this,Direction.UPRIGHT);
	}
	public void moveUpLeft()throws UnallowedMovementException{
		throw new UnallowedMovementException(this,Direction.UPLEFT);
	}
	public void moveDownRight()throws UnallowedMovementException{
		throw new UnallowedMovementException(this,Direction.DOWNRIGHT);
	}
	public void moveDownLeft()throws UnallowedMovementException{
		throw new UnallowedMovementException(this,Direction.DOWNLEFT);
	}
	

	public void usePower(Direction d,Piece target,Point newPos)throws InvalidPowerTargetException,InvalidPowerDirectionException,PowerAlreadyUsedException,WrongTurnException{


		super.usePower(d, target, newPos);
		
		int x=this.getPosI();
		int y=this.getPosJ();

		
		if(d==Direction.UPLEFT ){
			throw new InvalidPowerDirectionException("This direction is not allowed by the game rules",this,Direction.UPLEFT);
		}
		if(d==Direction.UPRIGHT ){
			throw new InvalidPowerDirectionException("This direction is not allowed by the game rules",this,Direction.UPRIGHT);
		}
		if(d==Direction.DOWNLEFT ){
			throw new InvalidPowerDirectionException("This direction is not allowed by the game rules",this,Direction.DOWNLEFT);
		}
		if(d==Direction.DOWNRIGHT){
			throw new InvalidPowerDirectionException("This direction is not allowed by the game rules",this,Direction.DOWNLEFT);
		}
		if(d==Direction.UP){
			for(int i=0;i<2;i++){
				if(x==0){
					this.setPowerUsed(true);
					this.getGame().switchTurns();
					return;
				} 
				if(this.getGame().getCellAt(--x,y).getPiece()!=null){
					if(this.getGame().getCellAt(x,y).getPiece().getOwner().equals(this.getOwner())){
						
					}
					else{
					this.attack(this.getGame().getCellAt(x,y).getPiece());
					}
			}}
		}
		if(d==Direction.DOWN){
			for(int i=0;i<2;i++){
				if(x==6){
					this.setPowerUsed(true);
					this.getGame().switchTurns();
					return;

				}
				if(this.getGame().getCellAt(++x,y).getPiece()!=null){
					if(this.getGame().getCellAt(x,y).getPiece().getOwner().equals(this.getOwner())){
						
					}
					else{
					this.attack(this.getGame().getCellAt(x,y).getPiece());
					}
			}}
		}
		if(d==Direction.LEFT){
			for(int i=0;i<2;i++){
				if(y==0){
					this.setPowerUsed(true);
					this.getGame().switchTurns();
					return;

				}
				if(this.getGame().getCellAt(x,--y).getPiece()!=null){
					if(this.getGame().getCellAt(x,y).getPiece().getOwner().equals(this.getOwner())){
						
					}
					else{
					this.attack(this.getGame().getCellAt(x,y).getPiece());
					}
			}}
		}if(d==Direction.RIGHT){
			for(int i=0;i<2;i++){
				if(y==5){
					this.setPowerUsed(true);
					this.getGame().switchTurns();
					return;

				}
				if(this.getGame().getCellAt(x,++y).getPiece()!=null){
					if(this.getGame().getCellAt(x,y).getPiece().getOwner().equals(this.getOwner())){
						
					}
					else{
					this.attack(this.getGame().getCellAt(x,y).getPiece());
					}
			}}
		}
		this.setPowerUsed(true);
		this.getGame().checkWinner();
		this.getGame().switchTurns();
		
		
	}
	
	
	
	
	
}
