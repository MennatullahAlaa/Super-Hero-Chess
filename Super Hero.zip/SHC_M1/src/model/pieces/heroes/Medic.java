package model.pieces.heroes;

import java.awt.Point;

import exceptions.InvalidPowerDirectionException;
import exceptions.InvalidPowerTargetException;
import exceptions.OccupiedCellException;
import exceptions.PowerAlreadyUsedException;
import exceptions.UnallowedMovementException;
import exceptions.WrongTurnException;
import model.game.Direction;
import model.game.Game;
import model.game.Player;
import model.pieces.Piece;

public class Medic extends ActivatablePowerHero {

	public Medic(Player player, Game game, String name) {
		super(player, game, name);
	}

	@Override
	public String toString() {
		return "M";
	}
	
	public void usePower(Direction d,Piece target,Point newPos)throws InvalidPowerTargetException,PowerAlreadyUsedException,InvalidPowerDirectionException,WrongTurnException{
		super.usePower(d, target, newPos);
		
		boolean check=true;
		
		if((!this.getOwner().getDeadCharacters().contains(target))&& target.getOwner()==this.getGame().getCurrentPlayer()){ //Revive an enemy piece
			throw new InvalidPowerTargetException("The target piece has not been eliminated before, so it cannot be revived",this,target);
		}
		if(target.getOwner()!=this.getGame().getCurrentPlayer()){
			throw new InvalidPowerTargetException("The target piece belongs to the enemy team",this,target);
			
		}
		
		
		int x=this.getPosI();
		int y=this.getPosJ();
		int size=this.getOwner().getDeadCharacters().size();
		
		if(d==Direction.UP){
			x=--x;
			if(x<0){
				this.setPowerUsed(true);
				this.getGame().switchTurns();
				return;
				
			}
			
		for(int i=0;i<size;i++){
			if(target.getClass() == (this.getOwner().getDeadCharacters().get(i)).getClass()){
				if(this.getGame().getCellAt(x,y).getPiece()!=null){
					throw new InvalidPowerTargetException("The target location is occupied",this,target);
				}
				else{
				this.getGame().getCellAt(x,y).setPiece(this.getOwner().getDeadCharacters().remove(i));
				this.getGame().getCellAt(x,y).getPiece().setPosI(x);
				this.getGame().getCellAt(x,y).getPiece().setPosI(y);
				check=false;break;
				
				}
				
			}
			}
		
		}
		
		if(d==Direction.DOWN){
			x=++x;
			if(x>6){
				this.setPowerUsed(true);
				this.getGame().switchTurns();
				return;
			}
			for(int i=0;i<size;i++){
				if(target.getClass()==(this.getOwner().getDeadCharacters().get(i).getClass())){
					if(this.getGame().getCellAt(x,y).getPiece()!=null){
						throw new InvalidPowerTargetException(this,target);
					}
					else{
					this.getGame().getCellAt(x,y).setPiece(this.getOwner().getDeadCharacters().remove(i));
					
					check=false;break;
					
					}
					
				}}
			}
		
			if(d==Direction.LEFT){
				y=--y;
				if(y<0){
					this.setPowerUsed(true);
					this.getGame().switchTurns();
					return;
				}
					for(int i=0;i<size;i++){
						if(target.getClass()==(this.getOwner().getDeadCharacters().get(i).getClass())){
							if(this.getGame().getCellAt(x,y).getPiece()!=null){
								throw new InvalidPowerTargetException("The target location is occupied",this,target);
							}
							else{
							this.getGame().getCellAt(x,y).setPiece(this.getOwner().getDeadCharacters().remove(i));
							
							check=false;break;
							
							}
							
						}}
					}
			
					if(d==Direction.RIGHT){
						y=++y;
						if(y>5){
							this.getGame().switchTurns();
							return;
						}
						for(int i=0;i<size;i++){
							if(target.getClass()==(this.getOwner().getDeadCharacters().get(i).getClass())){
								if(this.getGame().getCellAt(x,y).getPiece()!=null){
									throw new InvalidPowerTargetException("The target location is occupied",this,target);
								}
								else{
								this.getGame().getCellAt(x,y).setPiece(this.getOwner().getDeadCharacters().remove(i));
								
								check=false;break;
								
								}
								
							}}
						}
					
						if(d==Direction.DOWNRIGHT){
							x=++x;
							y=++y;
							if(x>6 || y>5){
								this.getGame().switchTurns();
								return;
							}
							for(int i=0;i<size;i++){
								if(target.getClass()==(this.getOwner().getDeadCharacters().get(i).getClass())){
									if(this.getGame().getCellAt(x,y).getPiece()!=null){
										throw new InvalidPowerTargetException("The target location is occupied",this,target);
									}
									else{
									this.getGame().getCellAt(x,y).setPiece(this.getOwner().getDeadCharacters().remove(i));
									
									check=false;break;
									
									}
									
								}}
							}

						if(d==Direction.UPRIGHT){
							x=--x;
							y=++y;
							if(x<0 || y>5){
								this.setPowerUsed(true);
								this.getGame().switchTurns();
								return;
							}
							for(int i=0;i<size;i++){
								if(target.getClass()==(this.getOwner().getDeadCharacters().get(i).getClass())){
									
									 if(this.getGame().getCellAt(x,y).getPiece()!=null ){
										throw new InvalidPowerTargetException("The target location is occupied",this,target);
									}
									else{
									this.getGame().getCellAt(x,y).setPiece(this.getOwner().getDeadCharacters().remove(i));
									
									check=false;break;
									
									}
									
								}}
							}

						if(d==Direction.UPLEFT){
							x=--x;
							y=--y;
							if(x<0 || y<0){
								this.setPowerUsed(true);
								this.getGame().switchTurns();
								return;
								
							}
							for(int i=0;i<size;i++){
								if(target.getClass()==(this.getOwner().getDeadCharacters().get(i).getClass())){
									if(this.getGame().getCellAt(x,y).getPiece()!=null){
										throw new InvalidPowerTargetException("The target location is occupied",this,target);
									}
									else{
									this.getGame().getCellAt(x,y).setPiece(this.getOwner().getDeadCharacters().remove(i));
								
									check=false;break;
									
									}
									
								}}
							}

						if(d==Direction.DOWNLEFT){
							x=++x;
							y=--y;
							if(x>6 || y<0){
								this.setPowerUsed(true);
								this.getGame().switchTurns();
								return;
								
							}
							for(int i=0;i<size;i++){
								if(target.getClass()==(this.getOwner().getDeadCharacters().get(i).getClass())){
									if(this.getGame().getCellAt(x,y).getPiece()!=null){
										throw new InvalidPowerTargetException("The target location is occupied",this,target);
									}
									else{
									this.getGame().getCellAt(x,y).setPiece(this.getOwner().getDeadCharacters().remove(i));
									
									check=false;break;
									}
									
								}
								}
							
							}

		this.getGame().getCellAt(x,y).getPiece().setPosI(x);
		this.getGame().getCellAt(x,y).getPiece().setPosJ(y); 
		
		if(target instanceof ActivatablePowerHero){
			((ActivatablePowerHero) target).setPowerUsed(false);
			
		}
		if(target instanceof Armored){
			((Armored)target).setArmorUp(true);	
		}
		this.setPowerUsed(true);
		this.getGame().switchTurns();		
	}
       public void moveUpRight() throws UnallowedMovementException{
    	   throw new UnallowedMovementException(this,Direction.UPRIGHT);
    	   
       }
       public void moveUpLeft()throws UnallowedMovementException{
    	   throw new UnallowedMovementException(this,Direction.UPLEFT);
    	   
       }
       public void moveDownLeft()throws UnallowedMovementException{
    	   throw new UnallowedMovementException(this,Direction.DOWNLEFT);
       }
       public void moveDownRight()throws UnallowedMovementException{
    	   throw new UnallowedMovementException(this,Direction.DOWNRIGHT);
       }

		
}
