package model.pieces.heroes;

import exceptions.OccupiedCellException;
import exceptions.UnallowedMovementException;
import exceptions.WrongTurnException;
import model.game.Direction;
import model.game.Game;
import model.game.Player;
import model.pieces.Piece;

public class Speedster extends NonActivatablePowerHero {

	public Speedster(Player player, Game game, String name) {
		super(player, game, name);
	}

	@Override
	public String toString() {
		return "S";
	}
	public void moveDownLeft()throws UnallowedMovementException,WrongTurnException,OccupiedCellException {
		
		int a=this.getDown(this.getPosI());
		a=this.getDown(a);
		int b=this.getLeft(this.getPosJ());
    	b=this.getLeft(b);
		if((this.getGame().getCellAt(a,b).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(a,b).getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.DOWNLEFT);
        }
		if(this.getGame().getCellAt(a,b).getPiece()==null){
			this.getGame().getCellAt(a,b).setPiece(this);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
			this.setPosI(a);
			this.setPosJ(b);
	
		}
		else{
			this.attack(this.getGame().getCellAt(a,b).getPiece());
			if(this.getGame().getCellAt(a,b).getPiece()==null){
				this.getGame().getCellAt(a,b).setPiece(this);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
				this.getGame().getCellAt(a,b).getPiece().setPosI(a);
				this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
				
			}
	    	
	    	
			
			
	    	
		}
		
		this.getGame().switchTurns();
		this.getGame().checkWinner();
		
	
   }
	
	public void moveDownRight()throws UnallowedMovementException,WrongTurnException,OccupiedCellException{
		
		int a=this.getDown(this.getPosI());
		a=this.getDown(a);
		int b=this.getRight(this.getPosJ());
    	b=this.getRight(b);
		if((this.getGame().getCellAt(a,b).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(a,b).getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.DOWNRIGHT);
        }
		if(this.getGame().getCellAt(a,b).getPiece()==null){
			this.getGame().getCellAt(a,b).setPiece(this);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
			this.setPosI(a);
			this.setPosJ(b);
		}
		else{
			this.attack(this.getGame().getCellAt(a,b).getPiece());
			if(this.getGame().getCellAt(a,b).getPiece()==null){
				this.getGame().getCellAt(a,b).setPiece(this);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
				this.setPosI(a);
				this.setPosJ(b);
				
			}
	    	
			
		}
		this.getGame().switchTurns();
		this.getGame().checkWinner();
		
	}
	
	public void moveLeft() throws UnallowedMovementException,WrongTurnException,OccupiedCellException{
		int a=this.getPosI();
		int b=this.getLeft(this.getPosJ());
    	b=this.getLeft(b);
		if((this.getGame().getCellAt(a,b).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(a,b).getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.LEFT);
        }
		if(this.getGame().getCellAt(a,b).getPiece()==null){
			this.getGame().getCellAt(a,b).setPiece(this);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
			this.setPosI(a);
			this.setPosJ(b);
		
		}
		else{
			this.attack(this.getGame().getCellAt(this.getPosI(),b).getPiece());
			if(this.getGame().getCellAt(a,b).getPiece()==null){
				this.getGame().getCellAt(a,b).setPiece(this);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
				this.setPosI(a);
				this.setPosJ(b);
				
			}
	    	
	    	
			
		}
		this.getGame().switchTurns();
		this.getGame().checkWinner();
		
	}
	
	public void moveRight() throws UnallowedMovementException,WrongTurnException,OccupiedCellException{
		int a=this.getPosI();
		int b=this.getRight(this.getPosJ());
    	b=this.getRight(b);
		if((this.getGame().getCellAt(a,b).getPiece()!=null)&&(this.getOwner().equals(this.getGame().getCellAt(a,b).getPiece().getOwner()))){
        	throw new OccupiedCellException(this,Direction.RIGHT);
        }
		if(this.getGame().getCellAt(a,b).getPiece()==null){
			this.getGame().getCellAt(a,b).setPiece(this);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
			this.setPosI(a);
			this.setPosJ(b);
	
		}
		else{
			this.attack(this.getGame().getCellAt(a,b).getPiece());
			if(this.getGame().getCellAt(a,b).getPiece()==null){
				this.getGame().getCellAt(a,b).setPiece(this);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
				this.setPosI(a);
				this.setPosJ(b);
				
			}
	   
			
		}
		this.getGame().switchTurns();
		this.getGame().checkWinner();
		
	}
	
	public void moveUp()throws UnallowedMovementException,WrongTurnException,OccupiedCellException{
		int a=this.getPosJ();
		int b=this.getUp(this.getPosI());
    	b=this.getUp(b);
		if((this.getGame().getCellAt(b,a).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(b,a).getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.UP);
        }
		if(this.getGame().getCellAt(b,a).getPiece()==null){
			this.getGame().getCellAt(b,a).setPiece(this);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
			this.setPosI(b);
			this.setPosJ(a);
		
		}
		else{
			this.attack(this.getGame().getCellAt(b,a).getPiece());
			if(this.getGame().getCellAt(b,a).getPiece()==null){
				this.getGame().getCellAt(b,a).setPiece(this);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
				this.setPosI(b);
				this.setPosJ(a);
				
			}
	    
	    	
			
		}
		this.getGame().switchTurns();
		this.getGame().checkWinner();
		
	}
	
	
	public void moveUpLeft()throws UnallowedMovementException,WrongTurnException,OccupiedCellException{
		
		int a=this.getUp(this.getPosI());
		a=this.getUp(a);
		int b=this.getLeft(this.getPosJ());
    	b=this.getLeft(b);
		if((this.getGame().getCellAt(a,b).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(a,b).getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.UPLEFT);
        }
		if(this.getGame().getCellAt(a,b).getPiece()==null){
			this.getGame().getCellAt(a,b).setPiece(this);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
			this.setPosI(a);
			this.setPosJ(b);
		
		}
		else{
			this.attack(this.getGame().getCellAt(a,b).getPiece());
			if(this.getGame().getCellAt(a,b).getPiece()==null){
				this.getGame().getCellAt(a,b).setPiece(this);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
				this.getGame().getCellAt(a,b).getPiece().setPosI(a);
				this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
				
			}
	    
	    	
			
		}
		this.getGame().switchTurns();
		this.getGame().checkWinner();
		
	}
	
	public void moveUpRight() throws UnallowedMovementException,WrongTurnException,OccupiedCellException{
		
		int a=this.getUp(this.getPosI());
		a=this.getUp(a);
		int b=this.getRight(this.getPosJ());
    	b=this.getRight(b);
		if((this.getGame().getCellAt(a,b).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(a,b).getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.UPRIGHT);
        }
		if(this.getGame().getCellAt(a,b).getPiece()==null){
			this.getGame().getCellAt(a,b).setPiece(this);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
			this.setPosI(a);
			this.setPosJ(b);
			
		}
		else{
			this.attack(this.getGame().getCellAt(a,b).getPiece());
			if(this.getGame().getCellAt(a,b).getPiece()==null){
				this.getGame().getCellAt(a,b).setPiece(this);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
				this.getGame().getCellAt(a,b).getPiece().setPosI(a);
				this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
				
			}
	    	
			
		}
		this.getGame().switchTurns();
		this.getGame().checkWinner();
		
		
	}
    
    public void moveDown()throws OccupiedCellException,UnallowedMovementException,WrongTurnException{
    	int a=this.getPosJ();
    	int b=this.getDown(this.getPosI());
    	b=this.getDown(b);
		if((this.getGame().getCellAt(b,a).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(b,a).getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.DOWN);
        }
		if(this.getGame().getCellAt(b,a).getPiece()==null){
			this.getGame().getCellAt(b,a).setPiece(this);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
			this.setPosJ(a);
			this.setPosI(b);
			//this.getGame().switchTurns();
		}
		else{
			this.attack(this.getGame().getCellAt(b,this.getPosJ()).getPiece());
			if(this.getGame().getCellAt(b,a).getPiece()==null){
				this.getGame().getCellAt(b,a).setPiece(this);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
				this.setPosI(b);
				this.setPosJ(a);
				
			}
	    	
	    	
		}
		this.getGame().switchTurns();
		this.getGame().checkWinner();
    	
    	
    }
	
}
