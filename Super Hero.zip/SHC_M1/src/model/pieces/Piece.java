package model.pieces;

import java.awt.Point;

import exceptions.OccupiedCellException;
import exceptions.UnallowedMovementException;
import exceptions.WrongTurnException;
import model.game.Cell;
import model.game.Direction;
import model.game.Game;
import model.game.Player;
import model.pieces.heroes.Armored;
import model.pieces.sidekicks.SideKick;

public abstract class Piece implements Movable {

	private String name;
	private Player owner;
	private Game game;
	private int posI;
	private int posJ;
	

	public Piece(Player p, Game g, String name) {
		this.owner = p;
		this.game = g;
		this.name = name;
	}
	
	

	public String getName() {
		return name;
	}

	public int getPosI() {
		return posI;
	}

	public void setPosI(int i) {
		posI = i;
	}

	public int getPosJ() {
		return posJ;
	}

	public void setPosJ(int j) {
		posJ = j;
	}

	public Game getGame() {
		return game;
	}

	public Player getOwner() {
		return owner;
	}

	public void attack(Piece target){
		
		if(target instanceof Armored){
			if(((Armored) target).isArmorUp()==true){
				((Armored)target).setArmorUp(false);
				
				return;
		}	
		}
	
		if(target!=null){
		
		    this.getGame().getCellAt(target.getPosI(), target.getPosJ()).setPiece(null); 
		}
		if(target instanceof SideKick){
			int temp1=this.getOwner().getSideKilled();
			temp1++;
			this.getOwner().setSideKilled(temp1);
			
			if(this.getOwner().getSideKilled()==2){
				int temp=this.getOwner().getPayloadPos();
				temp++;
				this.getOwner().setPayloadPos(temp);
				this.getOwner().setSideKilled(0);
			}
		
		}
		else{
			int temp=this.getOwner().getPayloadPos();
			temp++;
			this.getOwner().setPayloadPos(temp);	
			
		}
	
		this.getGame().checkWinner();
		this.getOwner().getDeadCharacters().add(target);
		
		

	}	

	

    public void move(Direction r)throws UnallowedMovementException,OccupiedCellException,WrongTurnException{
    	if(this.getOwner().equals(this.getGame().getCurrentPlayer())==false){
    		throw new WrongTurnException(this);
    	}
    	
    	int a=this.getPosI();
    	int b=this.getPosJ();
    	
    	if(r==Direction.DOWN){
    		this.moveDown();
    		
    	}
    	if(r==Direction.DOWNLEFT){
    		this.moveDownLeft();
    		
    	}
    	if(r==Direction.DOWNRIGHT){
    		this.moveDownRight();
    		
    	}
    	if(r==Direction.LEFT){
    		this.moveLeft();
    		
    	}
    	if(r==Direction.RIGHT){
    		this.moveRight();
    		
    	}
    	if(r==Direction.UP){
    		this.moveUp();
    		
    	}
    	if(r==Direction.UPLEFT){
    		this.moveUpLeft();
    		
    	}
    	if(r==Direction.UPRIGHT){
    		this.moveUpRight();
    		
    	}
    	
    	
    	
    }
    
    public void moveDownLeft()throws UnallowedMovementException,WrongTurnException,OccupiedCellException {
    	
    	int a=this.getDown(this.getPosI());
    	int b=this.getLeft(this.getPosJ());
		if((this.getGame().getCellAt(a,b).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(a,b).getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.DOWNLEFT);
        }
		if(this.getGame().getCellAt(a,b).getPiece()==null){
			this.getGame().getCellAt(a,b).setPiece(this);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
			this.getGame().getCellAt(a,b).getPiece().setPosI(a);
			this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
		
		}
		else{
			this.attack((this.getGame().getCellAt(a,b)).getPiece());
			if(this.getGame().getCellAt(a,b).getPiece()==null){
				this.getGame().getCellAt(a,b).setPiece(this);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
				this.getGame().getCellAt(a,b).getPiece().setPosI(a);
				this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
				
			}
		}
		this.getGame().checkWinner();
    	this.getGame().switchTurns();

    	
    		}
    	
    	
    	
	
   
	
	public void moveDownRight()throws UnallowedMovementException,WrongTurnException,OccupiedCellException{
		
		int a=this.getDown(this.getPosI());
    	int b=this.getRight(this.getPosJ());
		if((this.getGame().getCellAt(a,b).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(a,b).getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.DOWNRIGHT);
        }
		if(this.getGame().getCellAt(a,b).getPiece()==null){
			(this.getGame().getCellAt(a,b)).setPiece(this);
			(this.getGame().getCellAt(this.getPosI(),this.getPosJ())).setPiece(null);
			this.getGame().getCellAt(a,b).getPiece().setPosI(a);
			this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
		
		}
		else{
			this.attack((this.getGame().getCellAt(a,b)).getPiece());
			if(this.getGame().getCellAt(a,b).getPiece()==null){
				this.getGame().getCellAt(a,b).setPiece(this);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
				this.getGame().getCellAt(a,b).getPiece().setPosI(a);
				this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
				
			}
			
			
		}
	this.getGame().checkWinner();
    	this.getGame().switchTurns();
		
	}
	
	public void moveLeft() throws UnallowedMovementException,WrongTurnException,OccupiedCellException{                		
		int a=this.getPosI();
		int b=this.getLeft(this.getPosJ());
		if((this.getGame().getCellAt(a,b).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(a,b).getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.LEFT);
        }
		if(this.getGame().getCellAt(a,b).getPiece()==null){
			(this.getGame().getCellAt(a,b)).setPiece(this);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
			this.getGame().getCellAt(a,b).getPiece().setPosI(a);
			this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
		}
		else{
			this.attack(this.getGame().getCellAt(this.getPosI(),this.getLeft(this.getPosJ())).getPiece());
			if(this.getGame().getCellAt(a,b).getPiece()==null){
				this.getGame().getCellAt(a,b).setPiece(this);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
				this.getGame().getCellAt(a,b).getPiece().setPosI(a);
				this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
				
			}
		}
	this.getGame().checkWinner();
    this.getGame().switchTurns();
	
	}
	
	public void moveRight() throws UnallowedMovementException,WrongTurnException,OccupiedCellException{
		int a=this.getPosI();
		int b=this.getRight(this.getPosJ());
		
		if(this.getGame().getCellAt(a,b).getPiece()!=null && this.getOwner().equals(this.getGame().getCellAt(a,b).getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.RIGHT);
        }
		if(this.getGame().getCellAt(a,b).getPiece()==null){
			this.getGame().getCellAt(a,b).setPiece(this);
			
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
			this.getGame().getCellAt(a,b).getPiece().setPosI(a);
			this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
			//this.getGame().switchTurns();
		}
		else{
			this.attack(this.getGame().getCellAt(a,b).getPiece());
			if(this.getGame().getCellAt(a,b).getPiece()==null){
				this.getGame().getCellAt(a,b).setPiece(this);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
				this.getGame().getCellAt(a,b).getPiece().setPosI(a);
				this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
				
			}
			

		}
		this.getGame().checkWinner();
    	this.getGame().switchTurns();
    	
		
	}
	public int getUp(int x){
		if(x>0)
			return x-1;
		else
			return 6;
	}
	public int getDown(int x){
		if(x<6)
			return x+1;
		else
			return 0;
	}
	public int getRight(int y){
		if(y<5)
			return y+1;
		else
			return 0;
	}
	public int getLeft(int y){
		if(y>0)
			return y-1;
		else
			return 5;
	}
	
	public void moveUp()throws UnallowedMovementException,WrongTurnException,OccupiedCellException{
		
		int a=this.getUp(this.getPosI());
		int b=this.getPosJ();
		if((this.getGame().getCellAt(a,b).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(a,b).getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.UP);
        }
		if(this.getGame().getCellAt(a,b).getPiece()==null){
			this.getGame().getCellAt(a,b).setPiece(this);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
			this.getGame().getCellAt(a,b).getPiece().setPosI(a);
			this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
			
		}
		else{
			this.attack((this.getGame().getCellAt(this.getUp(this.getPosI()),this.getPosJ()).getPiece()));
			if(this.getGame().getCellAt(a,b).getPiece()==null){
				this.getGame().getCellAt(a,b).setPiece(this);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
				this.getGame().getCellAt(a,b).getPiece().setPosI(a);
				this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
				
			}
		}
		
		this.getGame().checkWinner();
    	this.getGame().switchTurns();
		
		
	}
	
	
	public void moveUpLeft()throws UnallowedMovementException,WrongTurnException,OccupiedCellException{
		
		int a=this.getUp(this.getPosI());
    	int b=this.getLeft(this.getPosJ());
		if((this.getGame().getCellAt(a,b).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(a,b).getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.UPLEFT);
        }
		if(this.getGame().getCellAt(a,b).getPiece()==null){
			this.getGame().getCellAt(a,b).setPiece(this);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
			this.getGame().getCellAt(a,b).getPiece().setPosI(a);
			this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
			
		}
		else{
			this.attack(this.getGame().getCellAt(a,b).getPiece());
			if(this.getGame().getCellAt(a,b).getPiece()==null){
				this.getGame().getCellAt(a,b).setPiece(this);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
				this.getGame().getCellAt(a,b).getPiece().setPosI(a);
				this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
				
			}
   
		}
		this.getGame().switchTurns();
    	this.getGame().checkWinner();
		
		
	}
	
	public void moveUpRight() throws UnallowedMovementException,WrongTurnException,OccupiedCellException{
		
		int a=this.getUp(this.getPosI());
    	int b=this.getRight(this.getPosJ());
		if((this.getGame().getCellAt(a,b).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(a,b).getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.UPRIGHT);
        }
		if(this.getGame().getCellAt(a,b).getPiece()==null){
			this.getGame().getCellAt(a,b).setPiece(this);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
			this.getGame().getCellAt(a,b).getPiece().setPosI(a);
			this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
			this.getGame().switchTurns();
		}
		else{
			this.attack(this.getGame().getCellAt(a,b).getPiece());
			if(this.getGame().getCellAt(a,b).getPiece()==null){
				this.getGame().getCellAt(a,b).setPiece(this);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
				this.getGame().getCellAt(a,b).getPiece().setPosI(a);
				this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
				
			}

		}
		this.getGame().switchTurns();
    	this.getGame().checkWinner();
		
		
	}
    
    public void moveDown()throws OccupiedCellException,UnallowedMovementException,WrongTurnException{
    	int a=this.getDown(this.getPosI());
    	int b=this.getPosJ();
    
		if((this.getGame().getCellAt(a,b).getPiece()!=null)&&this.getOwner().equals(this.getGame().getCellAt(a,b).getPiece().getOwner())){
        	throw new OccupiedCellException(this,Direction.DOWN);
        }
		
		if(this.getGame().getCellAt(a,b).getPiece()==null){
			this.getGame().getCellAt(a,b).setPiece(this);
			this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
			this.getGame().getCellAt(a,b).getPiece().setPosI(a);
			this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
		}
		else{
			this.attack(this.getGame().getCellAt(a,b).getPiece());
			if(this.getGame().getCellAt(a,b).getPiece()==null){
				this.getGame().getCellAt(a,b).setPiece(this);
				this.getGame().getCellAt(this.getPosI(),this.getPosJ()).setPiece(null);
				this.getGame().getCellAt(a,b).getPiece().setPosI(a);
				this.getGame().getCellAt(a,b).getPiece().setPosJ(b);
				
			}
      
		}
		this.getGame().switchTurns();
    	this.getGame().checkWinner();
		
    	
    	
    	
    }


}
