package model.game;

import exceptions.OccupiedCellException;
import exceptions.UnallowedMovementException;
import exceptions.WrongTurnException;
import model.pieces.Piece;
import model.pieces.heroes.Armored;
import model.pieces.heroes.Medic;
import model.pieces.heroes.Ranged;
import model.pieces.heroes.Speedster;
import model.pieces.heroes.Super;
import model.pieces.heroes.Tech;
import model.pieces.sidekicks.SideKickP1;
import model.pieces.sidekicks.SideKickP2;

public class Game {

	private final int payloadPosTarget = 6;
	private final int boardWidth = 6;
	private final int boardHeight = 7;
	private Player player1;
	private Player player2;
	private Player currentPlayer;
	private Cell[][] board;
	

	public Game(Player player1, Player player2) {
		this.player1 = player1;
		this.player2 = player2;
		currentPlayer = player1;
		board = new Cell[boardHeight][boardWidth];
		assemblePieces();
		
	}

	public Player getCurrentPlayer() {
		return currentPlayer;
	}

	public void setCurrentPlayer(Player currentPlayer) {
		this.currentPlayer = currentPlayer;
	}

	public Player getPlayer1() {
		return player1;
	}

	public Player getPlayer2() {
		return player2;
	}

	public int getPayloadPosTarget() {
		return payloadPosTarget;
	}

	@Override
	public String toString() {
		String s = "";
		System.out.println("      " + getPlayer2().getName());
		System.out.print("| ");
		for (int i = 0; i < board[0].length; i++)
			System.out.print("--");
		System.out.println("|");
		for (int i = 0; i < board.length; i++) {
			System.out.print("| ");
			for (int j = 0; j < board[0].length; j++) {
				if (board[i][j] == null)
					System.out.print("n ");
				else
					System.out.print(board[i][j] + " ");
			}
			System.out.println("|");
		}
		System.out.print("| ");
		for (int i = 0; i < board[0].length; i++)
			System.out.print("--");
		System.out.println("|");
		System.out.println("    " + getPlayer1().getName());
		return s;
	}

	public int getBoardWidth() {
		return boardWidth;
	}

	public int getBoardHeight() {
		return boardHeight;
	}
	
	
	public void assemblePieces(){
		
		for(int i=0;i<7;i++){
			for(int j=0;j<6;j++){
				board[i][j]=new Cell();
			}
		}
		
		int x=4;
		int y=2;
		
		for(int i=0;i<6;i++){
			this.board[x][i].setPiece(new SideKickP1(this,"SideKick"));
			this.board[x][i].getPiece().setPosI(x);
			this.board[x][i].getPiece().setPosJ(i);
		}
		
		for(int i=0;i<6;i++){
			this.board[y][i].setPiece(new SideKickP2(this,"SideKick"));	
			this.board[y][i].getPiece().setPosI(y);
			this.board[y][i].getPiece().setPosJ(i);
		}
		
		int[]array=new int[6];
		array[0]=0;
		array[1]=1;
		array[2]=2;
		array[3]=3;
		array[4]=4;
		array[5]=5;
		int[]array1=new int[6];
		array1[0]=0;
		array1[1]=1;
		array1[2]=2;
		array1[3]=3;
		array1[4]=4;
		array1[5]=5;
		
		
		int w=5;
		int z=1;
		int temp;
		int temp1;

		for(int i=0;i<6;i++){
			temp=(int)((Math.random()*6));
			while(array[temp]==9){
				temp=(int)((Math.random()*6));
			}
				switch (temp){
				case 0: this.board[w][i].setPiece(new Armored(player1,this,"Armored"));break;
				case 1: this.board[w][i].setPiece(new Medic(player1,this,"Medic"));break;
				case 2: this.board[w][i].setPiece(new Ranged(player1,this,"Ranged"));break;
				case 3: this.board[w][i].setPiece(new Speedster(player1,this,"Speedster"));break;
				case 4: this.board[w][i].setPiece(new Super(player1,this,"Super"));break;
				case 5: this.board[w][i].setPiece(new Tech(player1,this,"Tech"));break;	
				}
				this.board[w][i].getPiece().setPosI(w);
				this.board[w][i].getPiece().setPosJ(i);
				
				
			array[temp]=9;
		}
		
		for(int i=0;i<6;i++){
			temp1=(int)((Math.random()*6));
			while(array1[temp1]==9){
				temp1=(int)((Math.random()*6));
			}
				switch (temp1){
				case 0: board[z][i].setPiece(new Armored(player2,this,"Armored"));break;
				case 1: board[z][i].setPiece(new Medic(player2,this,"Medic"));break;
				case 2: board[z][i].setPiece(new Ranged(player2,this,"Ranged"));break;
				case 3: board[z][i].setPiece(new Speedster(player2,this,"Speedster"));break;
				case 4: board[z][i].setPiece(new Super(player2,this,"Super"));break;
				case 5: board[z][i].setPiece(new Tech(player2,this,"Tech"));break;	
				}
				this.board[z][i].getPiece().setPosI(z);
				this.board[z][i].getPiece().setPosJ(i);
			
			array1[temp1]=9;
		}
		
	}
	
	public Cell getCellAt(int i, int j){
		return board[i][j];
	}

	public boolean checkWinner(){

		if(currentPlayer.getPayloadPos()>=6)
			return true;
		return false;
	}

    public void switchTurns(){
    	if(this.getCurrentPlayer()==this.getPlayer1()){
    		currentPlayer=player2;
    	}
    	else{
    		currentPlayer=player1;
    	}
    }
   public static void main(String[]args){
    	Game g=new Game(new Player("Farah"),new Player("Hoss"));
    	System.out.println(g);
    	
    		try {
				g.getCellAt(4,2).getPiece().move(Direction.UP);
			} catch (UnallowedMovementException | OccupiedCellException
					| WrongTurnException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	
    	System.out.println(g);
    	try {
			g.getCellAt(2,2).getPiece().move(Direction.DOWN);
		} catch (UnallowedMovementException | OccupiedCellException
				| WrongTurnException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     	System.out.println(g);
    	
    	
    	
    	
    	
    	
    	
    	
    	
    
   }
}


